torchrun --nproc_per_node=2 SatMAE/main_finetune.py --eval \
--batch_size 32 \
--patch_size 8 \
--model vit_base_patch16 \
--model_type group_c \
--dataset_type sentinel --dropped_bands 0 9 10 \
--train_path fmow-sentinel-2/train.csv \
--test_path fmow-sentinel-2/test_1k.csv \
--resume SatMAE/trained_models/finetune-vit-base-e7.pth