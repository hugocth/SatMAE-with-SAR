torchrun --nproc_per_node=2 SatMAE/main_pretrain_mm.py \
--batch_size 32 --accum_iter 32 --blr 0.0001 \
--epochs 10 --warmup_epochs 1 --num_workers 16 \
--input_size 96 --patch_size 8 \
--model mae_vit_base_patch16 \
--model_type group_c \
--dataset_type bigearthnet --dropped_bands 0 9 \
--grouped_bands 0 1 2 6 --grouped_bands 3 4 5 7 --grouped_bands 8 9 --grouped_bands 10 11 \
--train_path bigearthnet-mm/train_filtered.csv \
