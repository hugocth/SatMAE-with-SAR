echo "Evaluating satMAE-MM-e5 fintuned on 30k images - all bands"

torchrun --nproc_per_node=2 SatMAE/main_finetune_mm.py --eval \
--batch_size 16 \
--patch_size 8 \
--model vit_base_patch16 \
--model_type group_c \
--dataset_type bigearthnet --dropped_bands 0 9 \
--train_path bigearthnet-mm/train_filtered.csv \
--test_path bigearthnet-mm/test_10k.csv \
--resume SatMAE/trained_models/fintuned-satMAE-MM-e1.pth

echo "Evaluating satMAE-MM-e5 fintuned on 30k images - dropping SAR group"

torchrun --nproc_per_node=2 SatMAE/main_finetune_mm.py --eval \
--batch_size 16 \
--patch_size 8 \
--model vit_base_patch16 \
--model_type group_c \
--dataset_type bigearthnet --dropped_bands 0 9 \
--masked_bands 10 11 \
--train_path bigearthnet-mm/train_filtered.csv \
--test_path bigearthnet-mm/test_10k.csv \
--resume SatMAE/trained_models/fintuned-satMAE-MM-e1.pth

echo "Evaluating satMAE-MM-e5 fintuned on 30k images - dropping RGB&NIR group"

torchrun --nproc_per_node=2 SatMAE/main_finetune_mm.py --eval \
--batch_size 16 \
--patch_size 8 \
--model vit_base_patch16 \
--model_type group_c \
--dataset_type bigearthnet --dropped_bands 0 9 \
--masked_bands 3 4 5 7 \
--train_path bigearthnet-mm/train_filtered.csv \
--test_path bigearthnet-mm/test_10k.csv \
--resume SatMAE/trained_models/fintuned-satMAE-MM-e1.pth

echo "Evaluating satMAE-MM-e5 fintuned on 30k images - dropping SWIR group"

torchrun --nproc_per_node=2 SatMAE/main_finetune_mm.py --eval \
--batch_size 16 \
--patch_size 8 \
--model vit_base_patch16 \
--model_type group_c \
--dataset_type bigearthnet --dropped_bands 0 9 \
--masked_bands 8 9 \
--train_path bigearthnet-mm/train_filtered.csv \
--test_path bigearthnet-mm/test_10k.csv \
--resume SatMAE/trained_models/fintuned-satMAE-MM-e1.pth